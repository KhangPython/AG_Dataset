# Traffic_Sign > 2024-11-01 9:57pm
https://universe.roboflow.com/project-4ti3k/traffic_sign-gv5rp-t0k2e-xxgnc

Provided by a Roboflow user
License: CC BY 4.0

